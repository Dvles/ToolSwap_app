@REM lancer fixtures -- 
symfony console doctrine:fixtures:load --no-interaction