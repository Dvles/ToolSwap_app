#makescrip executable: chmod +x clear_cache.sh
# Clear the cache
php bin/console cache:clear --env=prod