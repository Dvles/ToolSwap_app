<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/xdebug' => [[['_route' => '_profiler_xdebug', '_controller' => 'web_profiler.controller.profiler::xdebugAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
        '/borrow/tool' => [[['_route' => 'app_borrow_tool', '_controller' => 'App\\Controller\\BorrowToolController::index'], null, null, null, false, false, null]],
        '/' => [[['_route' => 'homepage', '_controller' => 'App\\Controller\\HomepageController::index'], null, null, null, false, false, null]],
        '/register' => [[['_route' => 'register', '_controller' => 'App\\Controller\\RegistrationController::register'], null, null, null, false, false, null]],
        '/login' => [[['_route' => 'app_login', '_controller' => 'App\\Controller\\SecurityController::login'], null, null, null, false, false, null]],
        '/logout' => [[['_route' => 'app_logout', '_controller' => 'App\\Controller\\SecurityController::logout'], null, null, null, false, false, null]],
        '/tool/availability' => [[['_route' => 'app_tool_availability', '_controller' => 'App\\Controller\\ToolAvailabilityController::index'], null, null, null, false, false, null]],
        '/tool/delete/availability' => [[['_route' => 'tool_availability_delete', '_controller' => 'App\\Controller\\ToolAvailabilityController::deleteToolAvailability'], null, null, null, true, false, null]],
        '/tool/upload' => [[['_route' => 'tool_upload', '_controller' => 'App\\Controller\\ToolController::toolUpload'], null, null, null, false, false, null]],
        '/display/tool/calendar' => [[['_route' => 'display_tool_calendar', '_controller' => 'App\\Controller\\ToolController::afficherCalendrierUtilisateur'], null, null, null, false, false, null]],
        '/tool/display/all' => [[['_route' => 'tool_display_all', '_controller' => 'App\\Controller\\ToolController::toolDisplayAll'], null, null, null, false, false, null]],
        '/tool/display/user' => [[['_route' => 'tool_display_user', '_controller' => 'App\\Controller\\ToolController::toolDisplayUser'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_(?'
                    .'|error/(\\d+)(?:\\.([^/]++))?(*:38)'
                    .'|wdt/([^/]++)(*:57)'
                    .'|profiler/(?'
                        .'|font/([^/\\.]++)\\.woff2(*:98)'
                        .'|([^/]++)(?'
                            .'|/(?'
                                .'|search/results(*:134)'
                                .'|router(*:148)'
                                .'|exception(?'
                                    .'|(*:168)'
                                    .'|\\.css(*:181)'
                                .')'
                            .')'
                            .'|(*:191)'
                        .')'
                    .')'
                .')'
                .'|/tool/(?'
                    .'|single/([^/]++)(?'
                        .'|/borrow(?'
                            .'|(*:239)'
                            .'|/(?'
                                .'|calendar(?'
                                    .'|(*:262)'
                                    .'|/confirm(*:278)'
                                .')'
                                .'|success(*:294)'
                            .')'
                        .')'
                        .'|(*:304)'
                    .')'
                    .'|add/availability/([^/]++)(*:338)'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        38 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        57 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        98 => [[['_route' => '_profiler_font', '_controller' => 'web_profiler.controller.profiler::fontAction'], ['fontName'], null, null, false, false, null]],
        134 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        148 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        168 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        181 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        191 => [[['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null]],
        239 => [[['_route' => 'tool_borrow', '_controller' => 'App\\Controller\\BorrowToolController::toolBorrow'], ['tool_id'], null, null, false, false, null]],
        262 => [[['_route' => 'tool_borrow_calendar', '_controller' => 'App\\Controller\\BorrowToolController::toolBorrowCalendar'], ['tool_id'], null, null, false, false, null]],
        278 => [[['_route' => 'tool_borrow_calendar_confirm', '_controller' => 'App\\Controller\\BorrowToolController::toolBorrowCalendarConfirm'], ['tool_id'], ['POST' => 0], null, false, false, null]],
        294 => [[['_route' => 'tool_borrow_success', '_controller' => 'App\\Controller\\BorrowToolController::borrowSuccess'], ['tool_id'], null, null, false, false, null]],
        304 => [[['_route' => 'tool_display_single', '_controller' => 'App\\Controller\\ToolController::toolDisplaySingle'], ['tool_id'], null, null, false, true, null]],
        338 => [
            [['_route' => 'tool_add_availability', '_controller' => 'App\\Controller\\ToolAvailabilityController::addToolAvailability'], ['tool_id'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
