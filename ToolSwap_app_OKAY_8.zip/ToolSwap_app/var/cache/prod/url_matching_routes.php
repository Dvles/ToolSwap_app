<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/borrow/tool' => [[['_route' => 'app_borrow_tool', '_controller' => 'App\\Controller\\BorrowToolController::index'], null, null, null, false, false, null]],
        '/' => [[['_route' => 'homepage', '_controller' => 'App\\Controller\\HomepageController::index'], null, null, null, false, false, null]],
        '/register' => [[['_route' => 'register', '_controller' => 'App\\Controller\\RegistrationController::register'], null, null, null, false, false, null]],
        '/login' => [[['_route' => 'app_login', '_controller' => 'App\\Controller\\SecurityController::login'], null, null, null, false, false, null]],
        '/logout' => [[['_route' => 'app_logout', '_controller' => 'App\\Controller\\SecurityController::logout'], null, null, null, false, false, null]],
        '/tool/availability' => [[['_route' => 'app_tool_availability', '_controller' => 'App\\Controller\\ToolAvailabilityController::index'], null, null, null, false, false, null]],
        '/tool/delete/availability' => [[['_route' => 'tool_availability_delete', '_controller' => 'App\\Controller\\ToolAvailabilityController::deleteToolAvailability'], null, null, null, true, false, null]],
        '/tool/upload' => [[['_route' => 'tool_upload', '_controller' => 'App\\Controller\\ToolController::toolUpload'], null, null, null, false, false, null]],
        '/display/tool/calendar' => [[['_route' => 'display_tool_calendar', '_controller' => 'App\\Controller\\ToolController::afficherCalendrierUtilisateur'], null, null, null, false, false, null]],
        '/tool/display/all' => [[['_route' => 'tool_display_all', '_controller' => 'App\\Controller\\ToolController::toolDisplayAll'], null, null, null, false, false, null]],
        '/tool/display/user' => [[['_route' => 'tool_display_user', '_controller' => 'App\\Controller\\ToolController::toolDisplayUser'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/tool/(?'
                    .'|single/([^/]++)(?'
                        .'|/borrow(?'
                            .'|(*:44)'
                            .'|/calendar(?'
                                .'|(*:63)'
                                .'|/confirm(*:78)'
                            .')'
                        .')'
                        .'|(*:87)'
                    .')'
                    .'|add/availability/([^/]++)(*:120)'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        44 => [[['_route' => 'tool_borrow', '_controller' => 'App\\Controller\\BorrowToolController::toolBorrow'], ['tool_id'], null, null, false, false, null]],
        63 => [[['_route' => 'tool_borrow_calendar', '_controller' => 'App\\Controller\\BorrowToolController::toolBorrowCalendar'], ['tool_id'], null, null, false, false, null]],
        78 => [[['_route' => 'tool_borrow_calendar_confirm', '_controller' => 'App\\Controller\\BorrowToolController::toolBorrowCalendarConfirm'], ['tool_id'], ['POST' => 0], null, false, false, null]],
        87 => [[['_route' => 'tool_display_single', '_controller' => 'App\\Controller\\ToolController::toolDisplaySingle'], ['tool_id'], null, null, false, true, null]],
        120 => [
            [['_route' => 'tool_add_availability', '_controller' => 'App\\Controller\\ToolAvailabilityController::addToolAvailability'], ['tool_id'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
